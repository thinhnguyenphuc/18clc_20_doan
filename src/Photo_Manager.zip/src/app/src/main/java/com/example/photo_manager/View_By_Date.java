package com.example.photo_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class View_By_Date extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view__by__date);



    }
}